(() => {
  const burger = document.querySelector('.burger');
  const mobileMenu = document.getElementById('mobile-menu');
  if (burger && mobileMenu) {
    burger.addEventListener('click', () => {
      const willOpen = mobileMenu.hasAttribute('hidden');
      mobileMenu.toggleAttribute('hidden', !willOpen);
      burger.setAttribute('aria-expanded', String(willOpen));
    });
    mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      mobileMenu.setAttribute('hidden', '');
      burger.setAttribute('aria-expanded', 'false');
    }));
  }

  document.getElementById('year').textContent = new Date().getFullYear();

  const reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: .12, rootMargin: '0px 0px -30px 0px' });
    reveals.forEach(el => io.observe(el));
  } else {
    reveals.forEach(el => el.classList.add('is-visible'));
  }

  const form = document.getElementById('quote-form');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const service = document.getElementById('service-select').value;
      const car = document.getElementById('car-input').value.trim();
      if (!service) return;
      const text = `Здравствуйте! Хочу уточнить стоимость и записаться в DSK Detailing.\nУслуга: ${service}.${car ? `\nАвтомобиль: ${car}.` : ''}`;
      window.open(`https://wa.me/79530812359?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    });
  }

  const images = [
    ['assets/photos/01-white-camry-rear.jpg','Белая Toyota Camry в студии DSK Detailing'],
    ['assets/photos/02-white-camry-rear-side.jpg','Белая Toyota Camry, вид сзади'],
    ['assets/photos/03-black-audi.jpg','Чёрный Audi'],
    ['assets/photos/04-studio-entrance.jpg','Вход в студию DSK Detailing'],
    ['assets/photos/05-white-car-studio.jpg','Автомобиль внутри студии'],
    ['assets/photos/06-black-mercedes-front.jpg','Чёрный Mercedes после детейлинга'],
    ['assets/photos/07-white-camry-front-top.jpg','Белая Toyota Camry, передняя часть'],
    ['assets/photos/08-black-bmw-rear.jpg','Чёрный BMW в студии'],
    ['assets/photos/09-black-mercedes-rear.jpg','Чёрный Mercedes, вид сзади'],
    ['assets/photos/10-white-camry-front.jpg','Белая Toyota Camry в студии'],
    ['assets/photos/11-wheel-detail.jpg','Колесо и кузов после ухода'],
    ['assets/photos/12-black-mercedes-hero.jpg','Чёрный Mercedes, вид спереди'],
    ['assets/photos/13-black-mercedes-side.jpg','Чёрный Mercedes, боковая часть'],
    ['assets/photos/14-dark-camry-rear.jpg','Тёмная Toyota Camry, задняя часть'],
    ['assets/photos/15-dark-camry-front-detail.jpg','Деталь тёмного кузова Toyota Camry'],
    ['assets/photos/16-white-camry-front-studio.jpg','Белая Toyota Camry после ухода'],
    ['assets/photos/17-dark-camry-side.jpg','Тёмная Toyota Camry, боковая часть']
  ];
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightbox-image');
  const counter = document.getElementById('lightbox-counter');
  let current = 0;

  const render = () => {
    const [src, alt] = images[current];
    lightboxImg.src = src;
    lightboxImg.alt = alt;
    counter.textContent = `${current + 1} / ${images.length}`;
  };
  const openAt = index => {
    current = Math.max(0, Math.min(images.length - 1, Number(index) || 0));
    render();
    lightbox.removeAttribute('hidden');
    document.body.classList.add('lightbox-open');
    lightbox.querySelector('.lightbox__close').focus();
  };
  const close = () => {
    lightbox.setAttribute('hidden', '');
    document.body.classList.remove('lightbox-open');
  };
  document.querySelectorAll('.gallery-open').forEach(btn => btn.addEventListener('click', () => openAt(btn.dataset.index)));
  document.getElementById('open-all-works')?.addEventListener('click', () => openAt(0));
  lightbox.querySelector('.lightbox__close').addEventListener('click', close);
  lightbox.querySelector('.lightbox__prev').addEventListener('click', () => { current = (current - 1 + images.length) % images.length; render(); });
  lightbox.querySelector('.lightbox__next').addEventListener('click', () => { current = (current + 1) % images.length; render(); });
  lightbox.addEventListener('click', e => { if (e.target === lightbox) close(); });
  document.addEventListener('keydown', e => {
    if (lightbox.hasAttribute('hidden')) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowLeft') { current = (current - 1 + images.length) % images.length; render(); }
    if (e.key === 'ArrowRight') { current = (current + 1) % images.length; render(); }
  });
})();
